// Tu peux ajouter ici des fonctions JS plus tard
console.log("Bienvenue sur DropActu !");